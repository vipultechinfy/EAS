﻿

function fnSuccessMessage(Response) {
    if (Response.Status) {
        if (parseInt($('#hdnEmpId').val()) > 0)
            ShowAlertLoad('Success', Response.Message, 'success', '/Admin/ViewEmployee');
        else
            ShowAlertLoad('Success', Response.Message, 'success', '/Admin/EmployeeRegistration');
    }
    else
        ShowAlert('Error', Response.Message, 'error');
}


$(document).on('click', '.spnEdit', function () {
    var EmpId = $(this).attr('empid');
    //$('#form0').load("/Admin/GetEmployeeDetailsById?Empid=" + EmpId);
    $.get('/Admin/EditEmployeeDetails', { EmpId: EmpId }, function (Response) { });
})

$(document).on('click', '.spnDelete', function () {
    var EmpId = $(this).attr('empid');

    if (window.confirm("Do you really want to delete this employee")) {
        $.post('/Admin/DeleteEmployee', { EmpId: EmpId }, function (Response) {
            //alert(Response.Message);
            //if (Response.Status) {
            //    location.href = '/Admin/EmployeeRegistration';
            //}
            if (Response.Status)
                ShowAlertLoad('Success', Response.Message, 'success', '/Admin/EmployeeRegistration');
            else
                ShowAlert('Error', Response.Message, 'error');
        });
    }
})


$(document).on('click', '#aShowPassword', function () {
    var aid = $(this).attr("actionid");
    var aText = $(this).text();
    if (aText == "Show Password") {
        $('#' + aid).attr('type', 'text');
        $(this).text('Hide Password');
    }
    else {
        $('#' + aid).attr('type', 'password');
        $(this).text('Show Password');
    }
});


$(document).on('click', '#btnReset', function () {
    var aid = $(this).attr("aval");
    if (aid == "0")
        location.href = '/Admin/EmployeeRegistration';
    else
        location.href = '/Admin/ViewEmployee';
});



$(document).on('keyup', '#txtEmployeeNameSearch', function () {
    var SearchValue = $(this).val().toLowerCase();
    $('#tblEmployeeDetails tr').each(function () {
        var EmployeeName = $(this).find('.EmployeeName').text().toLowerCase();
        if (EmployeeName.indexOf(SearchValue) === -1) {
            $(this).hide();
           // $(this).next('tr').removeClass('d-md-table-row');

        } else {
            $(this).show();
          //  $(this).next('tr').addClass('d-md-table-row');
        }
    });
});
