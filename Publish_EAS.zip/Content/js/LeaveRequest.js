﻿

function GetDataOnPageLoad() {
    var d1 = new Date();
    var d2 = d1.addDays(1);
    var FromDate = d1.toISOString().split('T')[0];
    var NewDate = d2.toISOString().split('T')[0];
    $('#txtdatefrom').val(NewDate);
    $("#txtdatefrom").attr('min', FromDate);
    $('#txtdatefrom').change();
    $('#btnSearch').click();
}

function fnSuccessMessage() {
    $('#divEmployeeLeaveRequest').load('/Employee/GetLeaveRequestData');
    $('#divEmployeeLeaveBalance').load('/Employee/GetLeaveBalanceData');
}

Date.prototype.addDays = function (days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}

function DateChange(dateFrom) {
    var d1 = new Date(dateFrom);
    var d2 = d1.addDays(2);

    var FromDate = d1.toISOString().split('T')[0];
    var NewDate = d2.toISOString().split('T')[0];
    $('#txtdateto').val(NewDate);
    $("#txtdateto").attr('min', FromDate);
}

$(document).on('change', '#txtdatefrom', function () {
    DateChange($(this).val());
})


function SaveLeaveCreationDetails() {
    var startDate = $('#txtdatefrom').val();
    var endDate = $('#txtdateto').val();
    var ids = null;
    var LeaveReason = $('#txtLeaveReason').val();
    if (LeaveReason == "") {
        $('#txtLeaveReason').focus();
        return false;
    }


    $("input:checkbox[class=selectdate]:checked").each(function () {
        if ($(this).is(":checked")) {

            if (ids == null) {
                ids = $(this).val();
            }
            else {
                ids = ids + "," + $(this).val();
            }
        }
    });

    if (ids == null) {
        $('#txtLeaveReason').focus();

        return false;
    }
    var DatejsonData = '';
    var HolidayData = '';

    var splitids = ids.split(',');
    // var leaveCount = splitids.length;
    for (var n = 0; n < splitids.length; n++) {
        var cid = splitids[n].trim();
        var holiday = $('#drpholiday_' + cid).val();
        var date = $('#spnDate_' + cid).text();
        if (holiday == "No") {
            DatejsonData = (DatejsonData == "" ? "" : DatejsonData + ",") + (date + "_" + $('#drpoption_' + cid).val());
        }
        else
            HolidayData = (HolidayData == "" ? "" : HolidayData + ",") + date;
    }
    var leaveCount = DatejsonData.split(',').length;
    var months = GetCurrentMonth();
    var id = $('#hdnIds').val();
    var jsonData = { Rid: id, DateRange: startDate + "|" + endDate, LeaveCount: leaveCount, LeaveDates: DatejsonData, HolidayDates: HolidayData, Months: months, LeaveReason: LeaveReason };

    $.post('/Employee/SaveLeaveRequest', jsonData, function (Response) {
        if (Response.Status) {
            if (parseInt($('#hdnIds').val()) == 0)
                ShowAlertLoad('Success', Response.Message, 'success', '/Employee/LeaveRequest');
            else
                ShowAlertLoad('Success', Response.Message, 'success', '/Employee/ShowLeaveRequest');
        }
        else
            ShowAlert('Error', Response.Message, 'error');
    });

}

function GetCurrentMonth() {
    var month = new Array();
    month[0] = "Jan";
    month[1] = "Feb";
    month[2] = "Mar";
    month[3] = "Apr";
    month[4] = "May";
    month[5] = "Jun";
    month[6] = "Jul";
    month[7] = "Aug";
    month[8] = "Sep";
    month[9] = "Oct";
    month[10] = "Nov";
    month[11] = "Dec";

    var d = new Date();
    var n = month[d.getMonth()] + ' ' + d.getFullYear();
    return n;
}

function Resetmaster() {
    if (parseInt($('#hdnIds').val()) == 0) {
        location.href = '/Employee/LeaveRequest';
    }
    else {
        location.href = '/Employee/ShowLeaveRequest';
    }
}


function GetLeaveDatabyId() {
    $.get('/Employee/GetLeaveRequestById', { Rid: parseInt($('#hdnIds').val()) }, function (Response) {
        if (Response != null) {
            BindLeaveData(Response);
        }
        else
            ShowAlertLoad('Error', 'Leave Request has not been load.', 'error', '/Employee/ShowLeaveRequest');
    });
}

function BindLeaveData(Response) {
    $('#txtLeaveReason').val(Response.LeaveReason);
    var daterange = Response.DateRange.split('|');
    var Leavedates = Response.LeaveDates.split(',');
    var HolidayDates = Response.HolidayDates.split(',');
    var startDate = daterange[0];
    var counter = 1;
    while (startDate <= daterange[1]) {
        LValue = '';
        for (var c = 0; c < Leavedates.length; c++) {
            var splitdate = Leavedates[c].split('_');
            if ($.trim(splitdate[0]) == $.trim(startDate)) {
                ids = 1;
                LValue = splitdate[1];
            }
        }
        var a = HolidayDates.indexOf(startDate);
        if (a > -1)
            $('#drpholiday_' + counter).val('Yes');

        $('#drpoption_' + counter).val(LValue);
        counter += 1;
        var d1 = new Date(startDate);
        var d2 = d1.addDays(1);
        var Newdate = d2.toISOString().split('T')[0];
        startDate = Newdate;
    }
}
