﻿

var pid = '';
var lat = '';
var lng = '';
var address = '';

$(document).ready(function () {
    getLocation();
});
// GeoLocation, Geocoding, Places

function getLocation() {
   
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    }
    else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {   

     lat = position.coords.latitude;
     lng = position.coords.longitude;
    var latlng = new google.maps.LatLng(lat, lng);
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {         
            if (results[0]) {
                pid = results[0].place_id;
                address = results[0].formatted_address;
                $('#map-default').attr("data-lat", lat);
                $('#map-default').attr("data-lng", lng);
               // initMap();
            }
        }
    });
}

function initMap() {

    map = document.getElementById('map-default');
    lat = map.getAttribute('data-lat');
    lng = map.getAttribute('data-lng');

    var myLatlng = new google.maps.LatLng(lat, lng);
    var mapOptions = {
        zoom: 12,
        scrollwheel: false,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
    }

    map = new google.maps.Map(map, mapOptions);

    var marker = new google.maps.Marker({
        position: myLatlng,
        map: map,
        animation: google.maps.Animation.DROP,
        title: 'You are Here!'
    });

    var contentString = '<div class="info-window-content"><h2>Techinfy </h2>' +
        '<p>Techingy Solutions Pvt Ltd.</p></div>';

    var infowindow = new google.maps.InfoWindow({
        content: contentString
    });

     const geocoder = new google.maps.Geocoder();

    //google.maps.event.addListener(marker, 'click', function () {
    //    //infowindow.open(map, marker);
    //    geocodePlaceId(geocoder, map, infowindow);
    //});

    geocodePlaceId(geocoder, map, infowindow);
}




// This function is called when the user clicks the UI button requesting
// a geocode of a place ID.
function geocodePlaceId(geocoder, map, infowindow) {
    const placeId = pid;
    geocoder.geocode({ placeId: placeId }, (results, status) => {
        if (status === "OK") {
            if (results[0]) {
                map.setZoom(12);                
                map.setCenter(results[0].geometry.location);
                const marker = new google.maps.Marker({
                    map,
                    position: results[0].geometry.location,
                    title: address,
                });
                infowindow.setContent(results[0].formatted_address);
                infowindow.open(map, marker);
            } else {
               // window.alert("No results found");
            }
        } else {
           // window.alert("Geocoder failed due to: " + status);
        }
    });
}
