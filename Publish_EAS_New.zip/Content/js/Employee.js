﻿

function fnSuccessMessage(Response) {
    if (Response.Status) {
        if (parseInt($('#hdnEmpId').val()) > 0)
            ShowAlertLoad('Success', Response.Message, 'success', '/Admin/ViewEmployee');
        else
            ShowAlertLoad('Success', Response.Message, 'success', '/Admin/EmployeeRegistration');
    }
    else
        ShowAlert('Error', Response.Message, 'error');
}


$(document).on('click', '.spnEdit', function () {
    var EmpId = $(this).attr('empid');
    //$('#form0').load("/Admin/GetEmployeeDetailsById?Empid=" + EmpId);
    $.get('/Admin/EditEmployeeDetails', { EmpId: EmpId }, function (Response) { });
})

$(document).on('click', '.spnDelete', function () {
    var EmpId = $(this).attr('empid');

    if (window.confirm("Do you really want to delete this employee")) {
        $.post('/Admin/DeleteEmployee', { EmpId: EmpId }, function (Response) {
            //alert(Response.Message);
            //if (Response.Status) {
            //    location.href = '/Admin/EmployeeRegistration';
            //}
            if (Response.Status)
                ShowAlertLoad('Success', Response.Message, 'success', '/Admin/EmployeeRegistration');
            else
                ShowAlert('Error', Response.Message, 'error');
        });
    }
})


$(document).on('click', '#aShowPassword', function () {
    var aid = $(this).attr("actionid");
    var aText = $(this).text();
    if (aText == "Show Password") {
        $('#' + aid).attr('type', 'text');
        $(this).text('Hide Password');
    }
    else {
        $('#' + aid).attr('type', 'password');
        $(this).text('Show Password');
    }
});