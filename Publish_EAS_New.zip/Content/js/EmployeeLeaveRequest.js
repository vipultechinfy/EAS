﻿


$(document).on('click', '.showLeaveRequest', function () {
    var rid = $(this).attr('rid');
    var empid = $(this).attr('empid');
    var aria = $(this).attr('aria-expanded');
    if (aria == undefined || aria == "false") {
        $.get("/Employee/GetEmployeeLeaveRequestLog", { EmpId: empid, Rid: rid }, function (Response) {
            if (Response != null && Response.length > 0) {
                $('#tbodyLeaveLog').empty();
                var tr = '';
                var dv = '';
                var Counter = 0;
                $.each(Response, function (i, v) {
                    if (dv != v.CreatedBy) {
                        dv = v.CreatedBy
                        tr = '<tr><td>' + (parseInt(Counter) + 1) + '</td>';
                        tr += '<td>' + (v.CreatedBy == 'Self' ? 'Employee' : v.CreatedBy) + '</td>';
                        tr += '<td>' + v.Status + '</td>';
                        tr += '<td>' + ApprovedStatus(v.IsApproved, v.IsActive, v.IsReject) + ' ' + (v.IsReject ? '<br /> <strong>Reason : &nbsp;</strong>' + v.RejectReason : "") + ' </td>';
                        tr += '<td>' + v.CreatedDate + '</td>';
                        $('#tbodyLeaveLog').append(tr);
                        Counter += 1;
                    }
                });
            }
        });
    }
});

function ApprovedStatus(IsApproved, IsActive, IsReject) {
    debugger;
    var returnValue = '';
    if (IsApproved && IsActive && !IsReject)
        returnValue = "Approved by Manager";
    else if (IsReject && !IsApproved)
        returnValue = "Reject by Manager";
    else if (IsApproved && !IsActive && !IsReject)
        returnValue = "Approved by Admin";
    else if (IsApproved && IsReject && !IsActive)
        returnValue = "Reject by Admin";
    else
        returnValue = "Leave Requested";
    return returnValue;
}

$(document).on('click', '.aLeaveUpdate', function () {
    var rid = $(this).attr('rid');
    var daterange = $(this).attr('daterange');
    $.post("/Employee/EditLeaveRequest", { Rid: rid, DateRange: daterange }, function (Response) {
        // alert('res');
    });
});

$(document).on('click', '.aUpdateRequest', function () {
    $('#hdnrid').val($(this).attr('rid'));
    $('#mdlLeaveUpdate').modal('show');
})

$(document).on('click', '#btnSubmit', function () {
    if (Validation()) {
        var jsondata = { Rid: $('#hdnrid').val(), Status: $('#ddlLeaveUpdate').val(), LeaveReason: $('#txtReason').val() };
        $.post("/Employee/UpdateLeaveRequest", jsondata, function (Response) {
            if (Response.Status) {
                ShowAlertLoad('Success', Response.Message, 'success', '/Employee/EmployeeLeaveRequest');
                $('#mdlLeaveUpdate').modal('hide');
            }
            else {
                ShowAlert('Error', Response.Message, 'error');
            }
        });
    }
});

function Validation() {
    var status = true;
    if ($('#ddlLeaveUpdate').val() == "") {
        $('#ddlLeaveUpdate').focus();
        $('#ddlLeaveUpdate').next('span').show();
        status = false;
    }
    else if ($('#ddlLeaveUpdate').val() == "Reject") {
        if ($('#txtReason').val() == "") {
            $('#txtReason').focus();
            $('#txtReason').next('span').show();
            status = false;
        }
    }
    return status;
}

$(document).on('click', '.clsRequest', function () {
    $(this).next('span').hide();
})


$(document).on('click', '#btnASubmit', function () {
    if (EValidation()) {
        var jsondata = { Rid: $('#hdnrid').val(), Status: $('#ddlLeaveUpdate').val(), LeaveReason: $('#txtReason').val() };
        $.post("/Admin/UpdateLeaveRequest", jsondata, function (Response) {
            if (Response.Status) {
                ShowAlertLoad('Success', Response.Message, 'success', '/Admin/EmployeeLeaveRequest');
                $('#mdlLeaveUpdate').modal('hide');
            }
            else {
                ShowAlert('Error', Response.Message, 'error');
            }
        });
    }
});

function EValidation() {
    var status = true;
    if ($('#ddlLeaveUpdate').val() == "") {
        $('#ddlLeaveUpdate').focus();
        $('#ddlLeaveUpdate').next('span').show();
        status = false;
    }
    else if ($('#ddlLeaveUpdate').val() == "Reject") {
        if ($('#txtReason').val() == "") {
            $('#txtReason').focus();
            $('#txtReason').next('span').show();
            status = false;
        }
    }
    return status;
}

$(document).on('click', '.clsRequest', function () {
    $(this).next('span').hide();
})

